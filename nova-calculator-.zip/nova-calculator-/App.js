import React, { useState } from 'react';

import {

  View, Text, TextInput, TouchableOpacity,

  ScrollView, StyleSheet, SafeAreaView, Image, Alert

} from 'react-native';

export default function App() {

  const [page, setPage] = useState('Basic');

  const [display, setDisplay] = useState('');

  const [history, setHistory] = useState([]);

  const [cost, setCost] = useState('');

  const [selling, setSelling] = useState('');

  const [amount, setAmount] = useState('');

  const [percent, setPercent] = useState('');

  const [from, setFrom] = useState('USD');

  const [to, setTo] = useState('NGN');

  const [currencyAmount, setCurrencyAmount] = useState('');

  const [currencyResult, setCurrencyResult] = useState('');

  const [currencyLoading, setCurrencyLoading] = useState(false);

  const addHistory = value => setHistory(old => [value, ...old]);

  const calculate = () => {

    try {

      if (!display.trim()) return;

      if (!/^[0-9+\-*/().% ]+$/.test(display)) throw new Error();

      const result = Function('"use strict";return (' + display.replace(/%/g, '/100') + ')')();

      if (!Number.isFinite(result)) throw new Error();

      const answer = String(Number(result.toFixed(8)));

      addHistory(display + ' = ' + answer);

      setDisplay(answer);

    } catch {

      setDisplay('Error');

    }

  };

  const scientific = type => {

    const n = Number(display);

    if (!Number.isFinite(n)) return;

    let r;

    if (type === 'sin') r = Math.sin(n * Math.PI / 180);

    if (type === 'cos') r = Math.cos(n * Math.PI / 180);

    if (type === 'tan') r = Math.tan(n * Math.PI / 180);

    if (type === 'sqrt') r = Math.sqrt(n);

    if (type === 'square') r = n * n;

    if (type === 'log') r = Math.log10(n);

    if (!Number.isFinite(r)) return setDisplay('Error');

    const answer = String(Number(r.toFixed(8)));

    addHistory(type + '(' + n + ') = ' + answer);

    setDisplay(answer);

  };

  const businessCalculate = () => {

    if (cost === '' || selling === '') {

      Alert.alert('Enter both prices');

      return;

    }

    const profit = Number(selling) - Number(cost);

    if (!Number.isFinite(profit)) return;

    addHistory('Business profit/loss = ' + profit);

    Alert.alert(

      profit >= 0 ? 'Your Profit' : 'Your Loss',

      '₦' + Math.abs(profit).toLocaleString()

    );

  };

  const percentageCalculate = () => {

    if (amount === '' || percent === '') {

      Alert.alert('Enter the amount and percentage');

      return;

    }

    const result = Number(amount) * Number(percent) / 100;

    const remaining = Number(amount) - result;

    addHistory(percent + '% of ' + amount + ' = ' + result);

    Alert.alert(

      'Percentage Result',

      'Discount: ' + result.toLocaleString() +

      '\nRemaining: ' + remaining.toLocaleString()

    );

  };

  const convertCurrency = async () => {

    if (!currencyAmount || Number(currencyAmount) < 0) return;

    setCurrencyLoading(true);

    setCurrencyResult('');

    try {

      const response = await fetch(`https://open.er-api.com/v6/latest/${from}`);

      const data = await response.json();

      if (!data.rates || !data.rates[to]) throw new Error();

      const result = Number(currencyAmount) * data.rates[to];

      const formatted = result.toLocaleString(undefined, {

        maximumFractionDigits: 2

      });

      setCurrencyResult(formatted + ' ' + to);

      addHistory(currencyAmount + ' ' + from + ' = ' + formatted + ' ' + to);

    } catch {

      setCurrencyResult('Conversion failed. Check your internet.');

    }

    setCurrencyLoading(false);

  };

  const button = (label, action, wide = false) => (

    <TouchableOpacity

      key={label}

      style={[styles.button, wide && styles.wide]}

      onPress={action}

    >

      <Text style={styles.buttonText}>{label}</Text>

    </TouchableOpacity>

  );

  const input = (placeholder, value, setter) => (

    <TextInput

      style={styles.input}

      placeholder={placeholder}

      placeholderTextColor="#8994A5"

      keyboardType="numeric"

      value={value}

      onChangeText={setter}

    />

  );

  const pages = ['Basic', 'Scientific', 'Business', 'Currency', 'Percent', 'History'];

  return (

    <SafeAreaView style={styles.container}>

      <View style={styles.header}>

        <Image

          source={require('./nova-icon.png')}

          style={styles.logo}

          resizeMode="contain"

        />

        <Text style={styles.subtitle}>SMART CALCULATOR</Text>

      </View>

      <ScrollView horizontal style={styles.tabs} showsHorizontalScrollIndicator={false}>

        {pages.map(item => (

          <TouchableOpacity

            key={item}

            style={[styles.tab, page === item && styles.activeTab]}

            onPress={() => setPage(item)}

          >

            <Text style={[styles.tabText, page === item && styles.activeTabText]}>

              {item}

            </Text>

          </TouchableOpacity>

        ))}

      </ScrollView>

      <ScrollView style={styles.content} keyboardShouldPersistTaps="handled">

        {page === 'Basic' && (

          <>

            <Text style={styles.title}>Basic Calculator</Text>

            <TextInput

              style={styles.display}

              value={display}

              onChangeText={setDisplay}

              placeholder="Enter calculation"

              placeholderTextColor="#8994A5"

              keyboardType="numbers-and-punctuation"

            />

            <View style={styles.grid}>

              {['7','8','9','÷','4','5','6','×','1','2','3','−','0','.','%','+'].map(item =>

                button(item, () => {

                  const v = {'÷':'/','×':'*','−':'-'}[item] || item;

                  setDisplay(old => old === 'Error' ? v : old + v);

                })

              )}

              {button('CLEAR', () => setDisplay(''), true)}

              {button('DELETE', () => setDisplay(old => old.slice(0, -1)), true)}

              {button('=', calculate, true)}

            </View>

          </>

        )}

        {page === 'Scientific' && (

          <>

            <Text style={styles.title}>Scientific Calculator</Text>

            <TextInput

              style={styles.display}

              value={display}

              onChangeText={setDisplay}

              placeholder="Enter a number"

              placeholderTextColor="#8994A5"

              keyboardType="numbers-and-punctuation"

            />

            <View style={styles.grid}>

              {['sin','cos','tan','sqrt','square','log'].map(item =>

                button(item, () => scientific(item))

              )}

              {button('CLEAR', () => setDisplay(''), true)}

            </View>

            <Text style={styles.note}>Trigonometry uses degrees.</Text>

          </>

        )}

        {page === 'Business' && (

          <>

            <Text style={styles.title}>Business Profit & Loss</Text>

            {input('Enter cost price (₦)', cost, setCost)}

            {input('Enter selling price (₦)', selling, setSelling)}

            {button('CALCULATE PROFIT / LOSS', businessCalculate, true)}

          </>

        )}

        {page === 'Currency' && (

          <>

            <Text style={styles.title}>Currency Converter</Text>

            {input('Enter amount', currencyAmount, setCurrencyAmount)}

            <Text style={styles.label}>From: {from}</Text>

            <View style={styles.grid}>

              {['USD','NGN','GBP','EUR'].map(x =>

                button(x, () => setFrom(x))

              )}

            </View>

            <Text style={styles.label}>To: {to}</Text>

            <View style={styles.grid}>

              {['USD','NGN','GBP','EUR'].map(x =>

                button(x, () => setTo(x))

              )}

            </View>

            {button(

              currencyLoading ? 'CONVERTING...' : 'CONVERT CURRENCY',

              convertCurrency,

              true

            )}

            {!!currencyResult && (

              <Text style={styles.result}>{currencyResult}</Text>

            )}

          </>

        )}

        {page === 'Percent' && (

          <>

            <Text style={styles.title}>Percentage & Discount</Text>

            {input('Enter amount (₦)', amount, setAmount)}

            {input('Enter percentage (%)', percent, setPercent)}

            {button('CALCULATE', percentageCalculate, true)}

          </>

        )}

        {page === 'History' && (

          <>

            <Text style={styles.title}>Calculation History</Text>

            {history.length === 0

              ? <Text style={styles.note}>No calculations yet.</Text>

              : history.map((item, index) => (

                  <Text key={index} style={styles.historyItem}>{item}</Text>

                ))}

            {button('CLEAR HISTORY', () => setHistory([]), true)}

          </>

        )}

      </ScrollView>

      <Text style={styles.footer}>NOVA CALCULATOR • 2026</Text>

    </SafeAreaView>

  );

}

const styles = StyleSheet.create({

  container: { flex: 1, backgroundColor: '#F3F7FC' },

  header: {

    backgroundColor: '#0756C9',

    padding: 12,

    alignItems: 'center'

  },

  logo: { width: 75, height: 75 },

  subtitle: {

    color: '#D8E8FF',

    fontSize: 11,

    letterSpacing: 3,

    marginTop: 4

  },

  tabs: { maxHeight: 58, backgroundColor: 'white' },

  tab: { paddingHorizontal: 17, paddingVertical: 18 },

  activeTab: { borderBottomWidth: 3, borderBottomColor: '#0756C9' },

  tabText: { color: '#65738A', fontWeight: '600' },

  activeTabText: { color: '#0756C9' },

  content: { flex: 1, padding: 18 },

  title: {

    fontSize: 23,

    fontWeight: 'bold',

    color: '#102A50',

    marginBottom: 20

  },

  display: {

    backgroundColor: 'white',

    borderRadius: 14,

    padding: 20,

    fontSize: 25,

    color: '#102A50',

    marginBottom: 16,

    minHeight: 75,

    textAlign: 'right'

  },

  grid: {

    flexDirection: 'row',

    flexWrap: 'wrap',

    justifyContent: 'space-between'

  },

  button: {

    backgroundColor: '#0756C9',

    width: '23%',

    minHeight: 55,

    borderRadius: 12,

    justifyContent: 'center',

    alignItems: 'center',

    marginBottom: 10

  },

  wide: { width: '100%', backgroundColor: '#063D91' },

  buttonText: { color: 'white', fontSize: 16, fontWeight: 'bold' },

  input: {

    backgroundColor: 'white',

    borderRadius: 12,

    padding: 17,

    fontSize: 17,

    marginBottom: 15,

    color: '#102A50'

  },

  label: { color: '#102A50', fontWeight: 'bold', marginBottom: 10 },

  note: { color: '#65738A', marginVertical: 12, fontSize: 14 },

  result: {

    fontSize: 23,

    color: '#0756C9',

    fontWeight: 'bold',

    marginTop: 20,

    textAlign: 'center'

  },

  historyItem: {

    backgroundColor: 'white',

    padding: 15,

    borderRadius: 10,

    marginBottom: 9,

    color: '#102A50',

    fontSize: 15

  },

  footer: {

    textAlign: 'center',

    padding: 12,

    color: '#8994A5',

    fontSize: 11,

    letterSpacing: 2

  }

});